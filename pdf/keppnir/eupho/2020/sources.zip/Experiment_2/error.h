// EuPhO 2020 Experimental Round - CONFIDENTIAL

#ifndef ERROR_H
#define ERROR_H

// Return random Gaussian error with given std dev.
double error(double stddev);

#endif // ERROR_H
